
-- --------------------------------------------------------

--
-- Structure de la table `t_categories`
--
-- Création :  sam. 18 nov. 2017 à 10:30
-- Dernière modification :  sam. 18 nov. 2017 à 10:31
--

DROP TABLE IF EXISTS `t_categories`;
CREATE TABLE IF NOT EXISTS `t_categories` (
  `idt_Categories` int(11) NOT NULL,
  `Categorie` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`idt_Categories`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tables des Catégories';

--
-- Déchargement des données de la table `t_categories`
--

INSERT INTO `t_categories` (`idt_Categories`, `Categorie`) VALUES
(1, 'Cuisine'),
(2, 'Education'),
(3, 'Photo'),
(4, 'Automobile'),
(5, 'Sport'),
(6, 'Animaux');
